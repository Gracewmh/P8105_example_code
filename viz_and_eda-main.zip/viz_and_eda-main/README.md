# Visualization and EDA

Some code from this topic in P8105.